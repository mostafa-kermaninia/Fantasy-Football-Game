#include "FutballFantasy.hpp"

int main()
{
    FutballFantasy Futball_Fantasy(LEAGUE_INFO_FILE_PATH);
    Futball_Fantasy.run();
    return 0;
}
